<?php
require_once('TCPDF/tcpdf.php');

class CustomPDF extends TCPDF {
    public function Header() {
    }
    public function Footer() {
    }
}

function fieldCard($eventData, $outputPath) {
        // Decode JSON to an associative array
        //$data = json_decode($eventData, true);
        $data = $eventData;
        // Check for JSON decoding errors
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo 'JSON decoding error: ' . json_last_error_msg();
            return;
        }
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            die("Error decoding JSON: " . json_last_error_msg());
        }
        echo "<pre>";
        print_r($data);  // Display the structure of decoded data for debugging
        echo "</pre>";

        $bib = [];
        $name = [];
        $club = [];
        $implement = [];
        $age = [];
        $county = [];

        // Ensure the expected nested structure exists
        if (isset($data['Athletes']) && is_array($data['Athletes'])) {
            foreach ($data['Athletes'] as $athlete) {
                // Check each athlete entry is an array before accessing fields
                if (is_array($athlete)) {
                    $bib[] = $athlete['Bib Number'] ?? "";
                    $name[] = $athlete['Name'] ?? "";
                    $club[] = $athlete['Club'] ?? "";
                    $implement[] = $athlete['Implement'] ?? "";
                    $age[] = $athlete['Age'] ?? "";
                    $county[] = $athlete['County'] ?? "";
                } else {
                    // Add empty values if the athlete entry is not in expected format
                    $bib[] = "";
                    $name[] = "";
                    $club[] = "";
                    $implement[] = "";
                    $age[] = "";
                    $county[] = "";
                }
            }
        } else {
            // Handle the case where 'Athletes' is missing or not an array
            echo "No valid athlete data available.";
        }

        foreach ($data as $event) {
            $competitionName = $event['Competition Name'];
            $eventType = $event['Event Type'];
            $eventName = $event['Event Name'];
            $venueName = $event['Venue Name'];
            $eventTime = $event['Event Time'];
            $eventDate = $event['Date'];
            $athletes = $event['Athletes'];

            
            if (in_array($eventType, ['LJ', 'SLJ'])) {
                // Use the specific template for Long Jump ('LJ', 'SLJ')
                $templateImage = 'templates/LJ.png';
                $pdf = new CustomPDF('L', 'mm', 'A4', true, 'UTF-8', false);

                $pdf->SetCreator(PDF_CREATOR);
                $pdf->SetAuthor('Athletics.app');
                $pdf->SetTitle('Long Jump Field Card');
                $pdf->SetSubject('Athletics.app');
                $pdf->SetKeywords('Athletics.app');

                $pdf->AddPage('L', 'A4');

                $bMargin = $pdf->getBreakMargin();
                $auto_page_break = $pdf->getAutoPageBreak();
                $pdf->SetAutoPageBreak(false, 0);
                $pdf->Image($templateImage, 0, 0, 297, 210, '', '', '', false, 300, '', false, false, 0);
                $pdf->SetAutoPageBreak($auto_page_break, $bMargin);
                $pdf->setPageMark();

                $pdf->SetFont('helvetica', '', 11);
                $pdf->SetTextColor(0, 0, 0);

                $data = [
                    ["value" => $eventName, "x" => 16.5, "y" => 19, "max_length" =>90],
                    ["value" => $eventDate, "x" => 219, "y" => 19, "max_length" => 15],
                    ["value" => $competitionName, "x" => 7, "y" => 27, "max_length" => 70],
                    ["value" => $venueName, "x" => 180, "y" => 27, "max_length" => 48],
                    ["value" => $bib[0], "x" => 7, "y" => 46, "max_length" => 4],
                    ["value" => $name[0], "x" => 16.5, "y" => 46, "max_length" => 15],
                    ["value" => $club[0], "x" => 48.5, "y" => 46, "max_length" => 8],
                    ["value" => $age[0], "x" => 69.5, "y" => 46, "max_length" => 4],
                    ["value" => $county[0], "x" => 80.5, "y" => 46, "max_length" => 15],
                    ["value" => $bib[1], "x" => 7, "y" => 52, "max_length" => 4],
                    ["value" => $name[1], "x" => 16.5, "y" => 52, "max_length" => 15],
                    ["value" => $club[1], "x" => 48.5, "y" => 52, "max_length" => 8],
                    ["value" => $age[1], "x" => 69.5, "y" => 52, "max_length" => 4],
                    ["value" => $county[1], "x" => 80.5, "y" => 52, "max_length" => 15],
                    ["value" => $bib[2], "x" => 7, "y" => 58, "max_length" => 4],
                    ["value" => $name[2], "x" => 16.5, "y" => 58, "max_length" => 15],
                    ["value" => $club[2], "x" => 48.5, "y" => 58, "max_length" => 8],
                    ["value" => $age[2], "x" => 69.5, "y" => 58, "max_length" => 4],
                    ["value" => $county[2], "x" => 80.5, "y" => 58, "max_length" => 15],
                    ["value" => $bib[3], "x" => 7, "y" => 64, "max_length" => 4],
                    ["value" => $name[3], "x" => 16.5, "y" => 64, "max_length" => 15],
                    ["value" => $club[3], "x" => 48.5, "y" => 64, "max_length" => 8],
                    ["value" => $age[3], "x" => 69.5, "y" => 64, "max_length" => 4],
                    ["value" => $county[3], "x" => 80.5, "y" => 64, "max_length" => 15],
                    ["value" => $bib[4], "x" => 7, "y" => 70.3, "max_length" => 4],
                    ["value" => $name[4], "x" => 16.5, "y" => 70.3, "max_length" => 15],
                    ["value" => $club[4], "x" => 48.5, "y" => 70.3, "max_length" => 8],
                    ["value" => $age[4], "x" => 69.5, "y" => 70.3, "max_length" => 4],
                    ["value" => $county[4], "x" => 80.5, "y" => 70.3, "max_length" => 15],
                    ["value" => $bib[5], "x" => 7, "y" => 76.6, "max_length" => 4],
                    ["value" => $name[5], "x" => 16.5, "y" => 76.6, "max_length" => 15],
                    ["value" => $club[5], "x" => 48.5, "y" => 76.6, "max_length" => 8],
                    ["value" => $age[5], "x" => 69.5, "y" => 76.6, "max_length" => 4],
                    ["value" => $county[5], "x" => 80.5, "y" => 76.6, "max_length" => 15],
                    ["value" => $bib[6], "x" => 7, "y" => 82.3, "max_length" => 4],
                    ["value" => $name[6], "x" => 16.5, "y" => 82.3, "max_length" => 15],
                    ["value" => $club[6], "x" => 48.5, "y" => 82.3, "max_length" => 8],
                    ["value" => $age[6], "x" => 69.5, "y" => 82.3, "max_length" => 4],
                    ["value" => $county[6], "x" => 80.5, "y" => 82.3, "max_length" => 15],
                    ["value" => $bib[7], "x" => 7, "y" => 88.3, "max_length" => 4],
                    ["value" => $name[7], "x" => 16.5, "y" => 88.3, "max_length" => 15],
                    ["value" => $club[7], "x" => 48.5, "y" => 88.3, "max_length" => 8],
                    ["value" => $age[7], "x" => 69.5, "y" => 88.3, "max_length" => 4],
                    ["value" => $county[7], "x" => 80.5, "y" => 88.3, "max_length" => 15],
                    ["value" => $bib[8], "x" => 7, "y" => 94.2, "max_length" => 4],
                    ["value" => $name[8], "x" => 16.5, "y" => 94.2, "max_length" => 15],
                    ["value" => $club[8], "x" => 48.5, "y" => 94.2, "max_length" => 8],
                    ["value" => $age[8], "x" => 69.5, "y" => 94.2, "max_length" => 4],
                    ["value" => $county[8], "x" => 80.5, "y" => 94.2, "max_length" => 15],
                    ["value" => $bib[9], "x" => 7, "y" => 100.5, "max_length" => 4],
                    ["value" => $name[9], "x" => 16.5, "y" => 100.5, "max_length" => 15],
                    ["value" => $club[9], "x" => 48.5, "y" => 100.5, "max_length" => 8],
                    ["value" => $age[9], "x" => 69.5, "y" => 100.5, "max_length" => 4],
                    ["value" => $county[9], "x" => 80.5, "y" => 100.5, "max_length" => 15],
                    ["value" => $bib[10], "x" => 7, "y" => 106.5, "max_length" => 4],
                    ["value" => $name[10], "x" => 16.5, "y" => 106.5, "max_length" => 15],
                    ["value" => $club[10], "x" => 48.5, "y" => 106.5, "max_length" => 8],
                    ["value" => $age[10], "x" => 69.5, "y" => 106.5, "max_length" => 4],
                    ["value" => $county[10], "x" => 80.5, "y" => 106.5, "max_length" => 15],
                    ["value" => $bib[11], "x" => 7, "y" => 112.4, "max_length" => 4],
                    ["value" => $name[11], "x" => 16.5, "y" => 112.4, "max_length" => 15],
                    ["value" => $club[11], "x" => 48.5, "y" => 112.4, "max_length" => 8],
                    ["value" => $age[11], "x" => 69.5, "y" => 112.4, "max_length" => 4],
                    ["value" => $county[11], "x" => 80.5, "y" => 112.4, "max_length" => 15],
                    ["value" => $bib[12], "x" => 7, "y" => 118.1, "max_length" => 4],
                    ["value" => $name[12], "x" => 16.5, "y" => 118.1, "max_length" => 15],
                    ["value" => $club[12], "x" => 48.5, "y" => 118.1, "max_length" => 8],
                    ["value" => $age[12], "x" => 69.5, "y" => 118.1, "max_length" => 4],
                    ["value" => $county[12], "x" => 80.5, "y" => 118.1, "max_length" => 15],
                    ["value" => $bib[13], "x" => 7, "y" => 124.3, "max_length" => 4],
                    ["value" => $name[13], "x" => 16.5, "y" => 124.3, "max_length" => 15],
                    ["value" => $club[13], "x" => 48.5, "y" => 124.3, "max_length" => 8],
                    ["value" => $age[13], "x" => 69.5, "y" => 124.3, "max_length" => 4],
                    ["value" => $county[13], "x" => 80.5, "y" => 124.3, "max_length" => 15],
                    ["value" => $bib[14], "x" => 7, "y" => 129.6, "max_length" => 4],
                    ["value" => $name[14], "x" => 16.5, "y" => 129.6, "max_length" => 15],
                    ["value" => $club[14], "x" => 48.5, "y" => 129.6, "max_length" => 8],
                    ["value" => $age[14], "x" => 69.5, "y" => 129.6, "max_length" => 4],
                    ["value" => $county[14], "x" => 80.5, "y" => 129.6, "max_length" => 15],
                    ["value" => $bib[15], "x" => 7, "y" => 135.6, "max_length" => 4],
                    ["value" => $name[15], "x" => 16.5, "y" => 135.6, "max_length" => 15],
                    ["value" => $club[15], "x" => 48.5, "y" => 135.6, "max_length" => 8],
                    ["value" => $age[15], "x" => 69.5, "y" => 135.6, "max_length" => 4],
                    ["value" => $county[15], "x" => 80.5, "y" => 135.6, "max_length" => 15],
                    ["value" => $bib[16], "x" => 7, "y" => 141.3, "max_length" => 4],
                    ["value" => $name[16], "x" => 16.5, "y" => 141.3, "max_length" => 15],
                    ["value" => $club[16], "x" => 48.5, "y" => 141.3, "max_length" => 8],
                    ["value" => $age[16], "x" => 69.5, "y" => 141.3, "max_length" => 4],
                    ["value" => $county[16], "x" => 80.5, "y" => 141.3, "max_length" => 15],
                    ["value" => $bib[17], "x" => 7, "y" => 147.4, "max_length" => 4],
                    ["value" => $name[17], "x" => 16.5, "y" => 147.4, "max_length" => 15],
                    ["value" => $club[17], "x" => 48.5, "y" => 147.4, "max_length" => 8],
                    ["value" => $age[17], "x" => 69.5, "y" => 147.4, "max_length" => 4],
                    ["value" => $county[17], "x" => 80.5, "y" => 147.4, "max_length" => 15],
                    ["value" => $bib[18], "x" => 7, "y" => 153.6, "max_length" => 4],
                    ["value" => $name[18], "x" => 16.5, "y" => 153.6, "max_length" => 15],
                    ["value" => $club[18], "x" => 48.5, "y" => 153.6, "max_length" => 8],
                    ["value" => $age[18], "x" => 69.5, "y" => 153.6, "max_length" => 4],
                    ["value" => $county[18], "x" => 80.5, "y" => 153.6, "max_length" => 15],
                    ["value" => $bib[19], "x" => 7, "y" => 160, "max_length" => 4],
                    ["value" => $name[19], "x" => 16.5, "y" => 160, "max_length" => 15],
                    ["value" => $club[19], "x" => 48.5, "y" => 160, "max_length" => 8],
                    ["value" => $age[19], "x" => 69.5, "y" => 160, "max_length" => 4],
                    ["value" => $county[19], "x" => 80.5, "y" => 160, "max_length" => 15],
                    ["value" => $eventTime, "x" => 25, "y" => 166.3, "max_length" => 15],
                ];

                // Loop through the data array and write values onto the pdf
                foreach ($data as $item) {
                    $text = $item['value'];
                    $x = $item['x'];
                    $y = $item['y'];
                    $maxLength = $item['max_length'];
                    // Trim text
                    if (strlen($text) > $maxLength) {
                        $text = substr($text, 0, $maxLength) . '..';
                    }
                    // Write values at specific coordinates
                    $pdf->SetXY($x, $y);
                    $pdf->Cell(0, 10, $text, 0, 1);
                }

                // Output PDF to browser in A4 landscape format
                $pdf->Output($outputPath, 'F'); // 'I' for inline display in browser

            }elseif (in_array($eventType, ['TJ'])) {
                // Use the specific template for Triple Jump ('TJ')
                $templateImage = 'templates/TJ.png';
                $pdf = new CustomPDF('L', 'mm', 'A4', true, 'UTF-8', false);

                $pdf->SetCreator(PDF_CREATOR);
                $pdf->SetAuthor('Athletics.app');
                $pdf->SetTitle('Triple Jump Field Card');
                $pdf->SetSubject('Athletics.app');
                $pdf->SetKeywords('Athletics.app');

                $pdf->AddPage('L', 'A4');

                $bMargin = $pdf->getBreakMargin();
                $auto_page_break = $pdf->getAutoPageBreak();
                $pdf->SetAutoPageBreak(false, 0);
                $pdf->Image($templateImage, 0, 0, 297, 210, '', '', '', false, 300, '', false, false, 0);
                $pdf->SetAutoPageBreak($auto_page_break, $bMargin);
                $pdf->setPageMark();

                $pdf->SetFont('helvetica', '', 11);
                $pdf->SetTextColor(0, 0, 0);

                $data = [
                    ["value" => $eventName, "x" => 16.5, "y" => 19, "max_length" =>90],
                    ["value" => $eventDate, "x" => 219, "y" => 19, "max_length" => 15],
                    ["value" => $competitionName, "x" => 7, "y" => 26.5, "max_length" => 70],
                    ["value" => $venueName, "x" => 185.5, "y" => 26.5, "max_length" => 48],
                    ["value" => $bib[0], "x" => 16.4, "y" => 44.3, "max_length" => 4],
                    ["value" => $name[0], "x" => 25.8, "y" => 44.3, "max_length" => 20],
                    ["value" => $club[0], "x" => 61.5, "y" => 44.3, "max_length" => 8],
                    ["value" => $age[0], "x" => 81.5, "y" => 44.3, "max_length" => 4],
                    ["value" => $county[0], "x" => 91.5, "y" => 44.3, "max_length" => 15],
                    ["value" => $bib[1], "x" => 16.4, "y" => 50, "max_length" => 4],
                    ["value" => $name[1], "x" => 25.8, "y" => 50, "max_length" => 20],
                    ["value" => $club[1], "x" => 61.5, "y" => 50, "max_length" => 8],
                    ["value" => $age[1], "x" => 81.5, "y" => 50, "max_length" => 4],
                    ["value" => $county[1], "x" => 91.5, "y" => 50, "max_length" => 15],
                    ["value" => $bib[2], "x" => 16.4, "y" => 55.9, "max_length" => 4],
                    ["value" => $name[2], "x" => 25.8, "y" => 55.9, "max_length" => 20],
                    ["value" => $club[2], "x" => 61.5, "y" => 55.9, "max_length" => 8],
                    ["value" => $age[2], "x" => 81.5, "y" => 55.9, "max_length" => 4],
                    ["value" => $county[2], "x" => 91.5, "y" => 55.9, "max_length" => 15],
                    ["value" => $bib[3], "x" => 16.4, "y" => 61.8, "max_length" => 4],
                    ["value" => $name[3], "x" => 25.8, "y" => 61.8, "max_length" => 20],
                    ["value" => $club[3], "x" => 61.5, "y" => 61.8, "max_length" => 8],
                    ["value" => $age[3], "x" => 81.5, "y" => 61.8, "max_length" => 4],
                    ["value" => $county[3], "x" => 91.5, "y" => 61.8, "max_length" => 15],
                    ["value" => $bib[4], "x" => 16.4, "y" => 67.1, "max_length" => 4],
                    ["value" => $name[4], "x" => 25.8, "y" => 67.1, "max_length" => 20],
                    ["value" => $club[4], "x" => 61.5, "y" => 67.1, "max_length" => 8],
                    ["value" => $age[4], "x" => 81.5, "y" => 67.1, "max_length" => 4],
                    ["value" => $county[4], "x" => 91.5, "y" => 67.1, "max_length" => 15],
                    ["value" => $bib[5], "x" => 16.4, "y" => 72.5, "max_length" => 4],
                    ["value" => $name[5], "x" => 25.8, "y" => 72.5, "max_length" => 20],
                    ["value" => $club[5], "x" => 61.5, "y" => 72.5, "max_length" => 8],
                    ["value" => $age[5], "x" => 81.5, "y" => 72.5, "max_length" => 4],
                    ["value" => $county[5], "x" => 91.5, "y" => 72.5, "max_length" => 15],
                    ["value" => $bib[6], "x" => 16.4, "y" => 78, "max_length" => 4],
                    ["value" => $name[6], "x" => 25.8, "y" => 78, "max_length" => 20],
                    ["value" => $club[6], "x" => 61.5, "y" => 78, "max_length" => 8],
                    ["value" => $age[6], "x" => 81.5, "y" => 78, "max_length" => 4],
                    ["value" => $county[6], "x" => 91.5, "y" => 78, "max_length" => 15],
                    ["value" => $bib[7], "x" => 16.4, "y" => 83.5, "max_length" => 4],
                    ["value" => $name[7], "x" => 25.8, "y" => 83.5, "max_length" => 20],
                    ["value" => $club[7], "x" => 61.5, "y" => 83.5, "max_length" => 8],
                    ["value" => $age[7], "x" => 81.5, "y" => 83.5, "max_length" => 4],
                    ["value" => $county[7], "x" => 91.5, "y" => 83.5, "max_length" => 15],
                    ["value" => $bib[8], "x" => 16.4, "y" => 89.3, "max_length" => 4],
                    ["value" => $name[8], "x" => 25.8, "y" => 89.3, "max_length" => 20],
                    ["value" => $club[8], "x" => 61.5, "y" => 89.3, "max_length" => 8],
                    ["value" => $age[8], "x" => 81.5, "y" => 89.3, "max_length" => 4],
                    ["value" => $county[8], "x" => 91.5, "y" => 89.3, "max_length" => 15],
                    ["value" => $bib[9], "x" => 16.4, "y" => 95.1, "max_length" => 4],
                    ["value" => $name[9], "x" => 25.8, "y" => 95.1, "max_length" => 20],
                    ["value" => $club[9], "x" => 61.5, "y" => 95.1, "max_length" => 8],
                    ["value" => $age[9], "x" => 81.5, "y" => 95.1, "max_length" => 4],
                    ["value" => $county[9], "x" => 91.5, "y" => 95.1, "max_length" => 15],
                    ["value" => $bib[10], "x" => 16.4, "y" => 101, "max_length" => 4],
                    ["value" => $name[10], "x" => 25.8, "y" => 101, "max_length" => 20],
                    ["value" => $club[10], "x" => 61.5, "y" => 101, "max_length" => 8],
                    ["value" => $age[10], "x" => 81.5, "y" => 101, "max_length" => 4],
                    ["value" => $county[10], "x" => 91.5, "y" => 101, "max_length" => 15],
                    ["value" => $bib[11], "x" => 16.4, "y" => 106.4, "max_length" => 4],
                    ["value" => $name[11], "x" => 25.8, "y" => 106.4, "max_length" => 20],
                    ["value" => $club[11], "x" => 61.5, "y" => 106.4, "max_length" => 8],
                    ["value" => $age[11], "x" => 81.5, "y" => 106.4, "max_length" => 4],
                    ["value" => $county[11], "x" => 91.5, "y" => 106.4, "max_length" => 15],
                    ["value" => $bib[12], "x" => 16.4, "y" => 112.4, "max_length" => 4],
                    ["value" => $name[12], "x" => 25.8, "y" => 112.4, "max_length" => 20],
                    ["value" => $club[12], "x" => 61.5, "y" => 112.4, "max_length" => 8],
                    ["value" => $age[12], "x" => 81.5, "y" => 112.4, "max_length" => 4],
                    ["value" => $county[12], "x" => 91.5, "y" => 112.4, "max_length" => 15],
                    ["value" => $bib[13], "x" => 16.4, "y" => 117.7, "max_length" => 4],
                    ["value" => $name[13], "x" => 25.8, "y" => 117.7, "max_length" => 20],
                    ["value" => $club[13], "x" => 61.5, "y" => 117.7, "max_length" => 8],
                    ["value" => $age[13], "x" => 81.5, "y" => 117.7, "max_length" => 4],
                    ["value" => $county[13], "x" => 91.5, "y" => 117.7, "max_length" => 15],
                    ["value" => $bib[14], "x" => 16.4, "y" => 123.4, "max_length" => 4],
                    ["value" => $name[14], "x" => 25.8, "y" => 123.4, "max_length" => 20],
                    ["value" => $club[14], "x" => 61.5, "y" => 123.4, "max_length" => 8],
                    ["value" => $age[14], "x" => 81.5, "y" => 123.4, "max_length" => 4],
                    ["value" => $county[14], "x" => 91.5, "y" => 123.4, "max_length" => 15],
                    ["value" => $bib[15], "x" => 16.4, "y" => 129, "max_length" => 4],
                    ["value" => $name[15], "x" => 25.8, "y" => 129, "max_length" => 20],
                    ["value" => $club[15], "x" => 61.5, "y" => 129, "max_length" => 8],
                    ["value" => $age[15], "x" => 81.5, "y" => 129, "max_length" => 4],
                    ["value" => $county[15], "x" => 91.5, "y" => 129, "max_length" => 15],
                    ["value" => $bib[16], "x" => 16.4, "y" => 134.5, "max_length" => 4],
                    ["value" => $name[16], "x" => 25.8, "y" => 134.5, "max_length" => 20],
                    ["value" => $club[16], "x" => 61.5, "y" => 134.5, "max_length" => 8],
                    ["value" => $age[16], "x" => 81.5, "y" => 134.5, "max_length" => 4],
                    ["value" => $county[16], "x" => 91.5, "y" => 134.5, "max_length" => 15],
                    ["value" => $bib[17], "x" => 16.4, "y" => 140, "max_length" => 4],
                    ["value" => $name[17], "x" => 25.8, "y" => 140, "max_length" => 20],
                    ["value" => $club[17], "x" => 61.5, "y" => 140, "max_length" => 8],
                    ["value" => $age[17], "x" => 81.5, "y" => 140, "max_length" => 4],
                    ["value" => $county[17], "x" => 91.5, "y" => 140, "max_length" => 15],
                    ["value" => $bib[18], "x" => 16.4, "y" => 145.5, "max_length" => 4],
                    ["value" => $name[18], "x" => 25.8, "y" => 145.5, "max_length" => 20],
                    ["value" => $club[18], "x" => 61.5, "y" => 145.5, "max_length" => 8],
                    ["value" => $age[18], "x" => 81.5, "y" => 145.5, "max_length" => 4],
                    ["value" => $county[18], "x" => 91.5, "y" => 145.5, "max_length" => 15],
                    ["value" => $bib[19], "x" => 16.4, "y" => 151.3, "max_length" => 4],
                    ["value" => $name[19], "x" => 25.8, "y" => 151.3, "max_length" => 20],
                    ["value" => $club[19], "x" => 61.5, "y" => 151.3, "max_length" => 8],
                    ["value" => $age[19], "x" => 81.5, "y" => 151.3, "max_length" => 4],
                    ["value" => $county[19], "x" => 91.5, "y" => 151.3, "max_length" => 15],
                    ["value" => $eventTime, "x" => 35, "y" => 157, "max_length" => 20],
                ];

                // Loop through the data array and write values onto the pdf
                foreach ($data as $item) {
                    $text = $item['value'];
                    $x = $item['x'];
                    $y = $item['y'];
                    $maxLength = $item['max_length'];
                    // Trim text
                    if (strlen($text) > $maxLength) {
                        $text = substr($text, 0, $maxLength) . '..';
                    }
                    // Write values at specific coordinates
                    $pdf->SetXY($x, $y);
                    $pdf->Cell(0, 10, $text, 0, 1);
                }

                // Output PDF to browser in A4 landscape format
                $pdf->Output($outputPath, 'F'); // 'I' for inline display in browser
                
            }elseif (in_array($eventType, ['HT', 'JT', 'WT', 'SP', 'DT', 'CT', 'ST'])) {
                // Use the specific template for Throws ('HT', 'JT', 'WT', 'SP', 'DT', 'CT', 'ST')
                $templateImage = 'templates/throws.png';
                $pdf = new CustomPDF('L', 'mm', 'A4', true, 'UTF-8', false);

                $pdf->SetCreator(PDF_CREATOR);
                $pdf->SetAuthor('Athletics.app');
                $pdf->SetTitle('Throws Field Card');
                $pdf->SetSubject('Athletics.app');
                $pdf->SetKeywords('Athletics.app');

                $pdf->AddPage('L', 'A4');

                $bMargin = $pdf->getBreakMargin();
                $auto_page_break = $pdf->getAutoPageBreak();
                $pdf->SetAutoPageBreak(false, 0);
                $pdf->Image($templateImage, 0, 0, 297, 210, '', '', '', false, 300, '', false, false, 0);
                $pdf->SetAutoPageBreak($auto_page_break, $bMargin);
                $pdf->setPageMark();

                $pdf->SetFont('helvetica', '', 11);
                $pdf->SetTextColor(0, 0, 0);

                $data = [
                    ["value" => $eventName, "x" => 16.5, "y" => 19, "max_length" =>90],
                    ["value" => $eventDate, "x" => 219, "y" => 19, "max_length" => 15],
                    ["value" => $competitionName, "x" => 7, "y" => 27, "max_length" => 70],
                    ["value" => $venueName, "x" => 182.5, "y" => 27, "max_length" => 48],
                    ["value" => $implement[0], "x" => 7, "y" => 45.6, "max_length" => 6],
                    ["value" => $bib[0], "x" => 21, "y" => 45.8, "max_length" => 4],
                    ["value" => $name[0], "x" => 30.5, "y" => 45.8, "max_length" => 15],
                    ["value" => $club[0], "x" => 61, "y" => 45.8, "max_length" => 8],
                    ["value" => $age[0], "x" => 82, "y" => 45.8, "max_length" => 4],
                    ["value" => $county[0], "x" => 93, "y" => 45.8, "max_length" => 15],
                    ["value" => $implement[1], "x" => 7, "y" => 52.3, "max_length" => 6],
                    ["value" => $bib[1], "x" => 21, "y" => 52.3, "max_length" => 4],
                    ["value" => $name[1], "x" => 30.5, "y" => 52.3, "max_length" => 15],
                    ["value" => $club[1], "x" => 61, "y" => 52.3, "max_length" => 8],
                    ["value" => $age[1], "x" => 82, "y" => 52.3, "max_length" => 4],
                    ["value" => $county[1], "x" => 93, "y" => 52.3, "max_length" => 15],
                    ["value" => $implement[2], "x" => 7, "y" => 58.1, "max_length" => 6],
                    ["value" => $bib[2], "x" => 21, "y" => 58.1, "max_length" => 4],
                    ["value" => $name[2], "x" => 30.5, "y" => 58.1, "max_length" => 15],
                    ["value" => $club[2], "x" => 61, "y" => 58.1, "max_length" => 8],
                    ["value" => $age[2], "x" => 82, "y" => 58.1, "max_length" => 4],
                    ["value" => $county[2], "x" => 93, "y" => 58.1, "max_length" => 15],
                    ["value" => $implement[3], "x" => 7, "y" => 64, "max_length" => 6],
                    ["value" => $bib[3], "x" => 21, "y" => 64, "max_length" => 4],
                    ["value" => $name[3], "x" => 30.5, "y" => 64, "max_length" => 15],
                    ["value" => $club[3], "x" => 61, "y" => 64, "max_length" => 8],
                    ["value" => $age[3], "x" => 82, "y" => 64, "max_length" => 4],
                    ["value" => $county[3], "x" => 93, "y" => 64, "max_length" => 15],
                    ["value" => $implement[4], "x" => 7, "y" => 70, "max_length" => 6],
                    ["value" => $bib[4], "x" => 21, "y" => 70, "max_length" => 4],
                    ["value" => $name[4], "x" => 30.5, "y" => 70, "max_length" => 15],
                    ["value" => $club[4], "x" => 61, "y" => 70, "max_length" => 8],
                    ["value" => $age[4], "x" => 82, "y" => 70, "max_length" => 4],
                    ["value" => $county[4], "x" => 93, "y" => 70, "max_length" => 15],
                    ["value" => $implement[5], "x" => 7, "y" => 76, "max_length" => 6],
                    ["value" => $bib[5], "x" => 21, "y" => 76, "max_length" => 4],
                    ["value" => $name[5], "x" => 30.5, "y" => 76, "max_length" => 15],
                    ["value" => $club[5], "x" => 61, "y" => 76, "max_length" => 8],
                    ["value" => $age[5], "x" => 82, "y" => 76, "max_length" => 4],
                    ["value" => $county[5], "x" => 93, "y" => 76, "max_length" => 15],
                    ["value" => $implement[6], "x" => 7, "y" => 82.3, "max_length" => 6],
                    ["value" => $bib[6], "x" => 21, "y" => 82.3, "max_length" => 4],
                    ["value" => $name[6], "x" => 30.5, "y" => 82.3, "max_length" => 15],
                    ["value" => $club[6], "x" => 61, "y" => 82.3, "max_length" => 8],
                    ["value" => $age[6], "x" => 82, "y" => 82.3, "max_length" => 4],
                    ["value" => $county[6], "x" => 93, "y" => 82.3, "max_length" => 15],
                    ["value" => $implement[7], "x" => 7, "y" => 88, "max_length" => 6],
                    ["value" => $bib[7], "x" => 21, "y" => 88, "max_length" => 4],
                    ["value" => $name[7], "x" => 30.5, "y" => 88, "max_length" => 15],
                    ["value" => $club[7], "x" => 61, "y" => 88, "max_length" => 8],
                    ["value" => $age[7], "x" => 82, "y" => 88, "max_length" => 4],
                    ["value" => $county[7], "x" => 93, "y" => 88, "max_length" => 15],
                    ["value" => $implement[8], "x" => 7, "y" => 93.8, "max_length" => 6],
                    ["value" => $bib[8], "x" => 21, "y" => 93.8, "max_length" => 4],
                    ["value" => $name[8], "x" => 30.5, "y" => 93.8, "max_length" => 15],
                    ["value" => $club[8], "x" => 61, "y" => 93.8, "max_length" => 8],
                    ["value" => $age[8], "x" => 82, "y" => 93.8, "max_length" => 4],
                    ["value" => $county[8], "x" => 93, "y" => 93.8, "max_length" => 15],
                    ["value" => $implement[9], "x" => 7, "y" => 99.9, "max_length" => 6],
                    ["value" => $bib[9], "x" => 21, "y" => 99.9, "max_length" => 4],
                    ["value" => $name[9], "x" => 30.5, "y" => 99.9, "max_length" => 15],
                    ["value" => $club[9], "x" => 61, "y" => 99.9, "max_length" => 8],
                    ["value" => $age[9], "x" => 82, "y" => 99.9, "max_length" => 4],
                    ["value" => $county[9], "x" => 93, "y" => 99.9, "max_length" => 15],
                    ["value" => $implement[10], "x" => 7, "y" => 106.2, "max_length" => 6],
                    ["value" => $bib[10], "x" => 21, "y" => 106.2, "max_length" => 4],
                    ["value" => $name[10], "x" => 30.5, "y" => 106.2, "max_length" => 15],
                    ["value" => $club[10], "x" => 61, "y" => 106.2, "max_length" => 8],
                    ["value" => $age[10], "x" => 82, "y" => 106.2, "max_length" => 4],
                    ["value" => $county[10], "x" => 93, "y" => 106.2, "max_length" => 15],
                    ["value" => $implement[11], "x" => 7, "y" => 112, "max_length" => 6],
                    ["value" => $bib[11], "x" => 21, "y" => 112, "max_length" => 4],
                    ["value" => $name[11], "x" => 30.5, "y" => 112, "max_length" => 15],
                    ["value" => $club[11], "x" => 61, "y" => 112, "max_length" => 8],
                    ["value" => $age[11], "x" => 82, "y" => 112, "max_length" => 4],
                    ["value" => $county[11], "x" => 93, "y" => 112, "max_length" => 15],
                    ["value" => $implement[12], "x" => 7, "y" => 118.3, "max_length" => 6],
                    ["value" => $bib[12], "x" => 21, "y" => 118.3, "max_length" => 4],
                    ["value" => $name[12], "x" => 30.5, "y" => 118.3, "max_length" => 15],
                    ["value" => $club[12], "x" => 61, "y" => 118.3, "max_length" => 8],
                    ["value" => $age[12], "x" => 82, "y" => 118.3, "max_length" => 4],
                    ["value" => $county[12], "x" => 93, "y" => 118.3, "max_length" => 15],
                    ["value" => $implement[13], "x" => 7, "y" => 124.3, "max_length" => 6],
                    ["value" => $bib[13], "x" => 21, "y" => 124.3, "max_length" => 4],
                    ["value" => $name[13], "x" => 30.5, "y" => 124.3, "max_length" => 15],
                    ["value" => $club[13], "x" => 61, "y" => 124.3, "max_length" => 8],
                    ["value" => $age[13], "x" => 82, "y" => 124.3, "max_length" => 4],
                    ["value" => $county[13], "x" => 93, "y" => 124.3, "max_length" => 15],
                    ["value" => $implement[14], "x" => 7, "y" => 129.8, "max_length" => 6],
                    ["value" => $bib[14], "x" => 21, "y" => 129.8, "max_length" => 4],
                    ["value" => $name[14], "x" => 30.5, "y" => 129.8, "max_length" => 15],
                    ["value" => $club[14], "x" => 61, "y" => 129.8, "max_length" => 8],
                    ["value" => $age[14], "x" => 82, "y" => 129.8, "max_length" => 4],
                    ["value" => $county[14], "x" => 93, "y" => 129.8, "max_length" => 15],
                    ["value" => $implement[15], "x" => 7, "y" => 135.8, "max_length" => 6],
                    ["value" => $bib[15], "x" => 21, "y" => 135.8, "max_length" => 4],
                    ["value" => $name[15], "x" => 30.5, "y" => 135.8, "max_length" => 15],
                    ["value" => $club[15], "x" => 61, "y" => 135.8, "max_length" => 8],
                    ["value" => $age[15], "x" => 82, "y" => 135.8, "max_length" => 4],
                    ["value" => $county[15], "x" => 93, "y" => 135.8, "max_length" => 15],
                    ["value" => $implement[16], "x" => 7, "y" => 142.1, "max_length" => 6],
                    ["value" => $bib[16], "x" => 21, "y" => 142.1, "max_length" => 4],
                    ["value" => $name[16], "x" => 30.5, "y" => 142.1, "max_length" => 15],
                    ["value" => $club[16], "x" => 61, "y" => 142.1, "max_length" => 8],
                    ["value" => $age[16], "x" => 82, "y" => 142.1, "max_length" => 4],
                    ["value" => $county[16], "x" => 93, "y" => 142.1, "max_length" => 15],
                    ["value" => $implement[17], "x" => 7, "y" => 148.4, "max_length" => 6],
                    ["value" => $bib[17], "x" => 21, "y" => 148.4, "max_length" => 4],
                    ["value" => $name[17], "x" => 30.5, "y" => 148.4, "max_length" => 15],
                    ["value" => $club[17], "x" => 61, "y" => 148.4, "max_length" => 8],
                    ["value" => $age[17], "x" => 82, "y" => 148.4, "max_length" => 4],
                    ["value" => $county[17], "x" => 93, "y" => 148.4, "max_length" => 15],
                    ["value" => $implement[18], "x" => 7, "y" => 153.8, "max_length" => 6],
                    ["value" => $bib[18], "x" => 21, "y" => 153.8, "max_length" => 4],
                    ["value" => $name[18], "x" => 30.5, "y" => 153.8, "max_length" => 15],
                    ["value" => $club[18], "x" => 61, "y" => 153.8, "max_length" => 8],
                    ["value" => $age[18], "x" => 82, "y" => 153.8, "max_length" => 4],
                    ["value" => $county[18], "x" => 93, "y" => 153.8, "max_length" => 15],
                    ["value" => $implement[19], "x" => 7, "y" => 159.7, "max_length" => 6],
                    ["value" => $bib[19], "x" => 21, "y" => 159.7, "max_length" => 4],
                    ["value" => $name[19], "x" => 30.5, "y" => 159.7, "max_length" => 15],
                    ["value" => $club[19], "x" => 61, "y" => 159.7, "max_length" => 8],
                    ["value" => $age[19], "x" => 82, "y" => 159.7, "max_length" => 4],
                    ["value" => $county[19], "x" => 93, "y" => 159.7, "max_length" => 15],
                    ["value" => $eventTime, "x" => 40, "y" => 165.9, "max_length" => 15],
                ];

                // Loop through the data array and write values onto the pdf
                foreach ($data as $item) {
                    $text = $item['value'];
                    $x = $item['x'];
                    $y = $item['y'];
                    $maxLength = $item['max_length'];
                    // Trim text
                    if (strlen($text) > $maxLength) {
                        $text = substr($text, 0, $maxLength) . '..';
                    }
                    // Write values at specific coordinates
                    $pdf->SetXY($x, $y);
                    $pdf->Cell(0, 10, $text, 0, 1);
                }

                // Output PDF to browser in A4 landscape format
                $pdf->Output($outputPath, 'F'); // 'I' for inline display in browser
                
                
            }elseif (in_array($eventType, ['HJ'])) {
                // Use the specific template for High Jump ('HJ')
                $templateImage = 'templates/HJ.png';
                $pdf = new CustomPDF('L', 'mm', 'A4', true, 'UTF-8', false);

                $pdf->SetCreator(PDF_CREATOR);
                $pdf->SetAuthor('Athletics.app');
                $pdf->SetTitle('High Jump Field Card');
                $pdf->SetSubject('Athletics.app');
                $pdf->SetKeywords('Athletics.app');

                $pdf->AddPage('L', 'A4');

                $bMargin = $pdf->getBreakMargin();
                $auto_page_break = $pdf->getAutoPageBreak();
                $pdf->SetAutoPageBreak(false, 0);
                $pdf->Image($templateImage, 0, 0, 297, 210, '', '', '', false, 300, '', false, false, 0);
                $pdf->SetAutoPageBreak($auto_page_break, $bMargin);
                $pdf->setPageMark();

                $pdf->SetFont('helvetica', '', 11);
                $pdf->SetTextColor(0, 0, 0);

                $data = [
                    ["value" => $eventName, "x" => 16.5, "y" => 19, "max_length" =>90],
                    ["value" => $eventDate, "x" => 210, "y" => 19, "max_length" => 15],
                    ["value" => $competitionName, "x" => 7, "y" => 26.1, "max_length" => 70],
                    ["value" => $venueName, "x" => 160, "y" => 26.1, "max_length" => 48],
                    ["value" => $bib[0], "x" => 18, "y" => 44.1, "max_length" => 4],
                    ["value" => $name[0], "x" => 27.6, "y" => 44.1, "max_length" => 20],
                    ["value" => $club[0], "x" => 60.6, "y" => 44.1, "max_length" => 8],
                    ["value" => $age[0], "x" => 80, "y" => 44.1, "max_length" => 4],
                    ["value" => $county[0], "x" => 89.5, "y" => 44.1, "max_length" => 5],
                    ["value" => $bib[1], "x" => 18, "y" => 49.7, "max_length" => 4],
                    ["value" => $name[1], "x" => 27.6, "y" => 49.7, "max_length" => 20],
                    ["value" => $club[1], "x" => 60.6, "y" => 49.7, "max_length" => 8],
                    ["value" => $age[1], "x" => 80, "y" => 49.7, "max_length" => 4],
                    ["value" => $county[1], "x" => 89.5, "y" => 49.7, "max_length" => 5],
                    ["value" => $bib[2], "x" => 18, "y" => 55.3, "max_length" => 4],
                    ["value" => $name[2], "x" => 27.6, "y" => 55.3, "max_length" => 20],
                    ["value" => $club[2], "x" => 60.6, "y" => 55.3, "max_length" => 8],
                    ["value" => $age[2], "x" => 80, "y" => 55.3, "max_length" => 4],
                    ["value" => $county[2], "x" => 89.5, "y" => 55.3, "max_length" => 5],
                    ["value" => $bib[3], "x" => 18, "y" => 61, "max_length" => 4],
                    ["value" => $name[3], "x" => 27.6, "y" => 61, "max_length" => 20],
                    ["value" => $club[3], "x" => 60.6, "y" => 61, "max_length" => 8],
                    ["value" => $age[3], "x" => 80, "y" => 61, "max_length" => 4],
                    ["value" => $county[3], "x" => 89.5, "y" => 61, "max_length" => 5],
                    ["value" => $bib[4], "x" => 18, "y" => 66.5, "max_length" => 4],
                    ["value" => $name[4], "x" => 27.6, "y" => 66.5, "max_length" => 20],
                    ["value" => $club[4], "x" => 60.6, "y" => 66.5, "max_length" => 8],
                    ["value" => $age[4], "x" => 80, "y" => 66.5, "max_length" => 4],
                    ["value" => $county[4], "x" => 89.5, "y" => 66.5, "max_length" => 5],
                    ["value" => $bib[5], "x" => 18, "y" => 72.1, "max_length" => 4],
                    ["value" => $name[5], "x" => 27.6, "y" => 72.1, "max_length" => 20],
                    ["value" => $club[5], "x" => 60.6, "y" => 72.1, "max_length" => 8],
                    ["value" => $age[5], "x" => 80, "y" => 72.1, "max_length" => 4],
                    ["value" => $county[5], "x" => 89.5, "y" => 72.1, "max_length" => 5],
                    ["value" => $bib[6], "x" => 18, "y" => 77.9, "max_length" => 4],
                    ["value" => $name[6], "x" => 27.6, "y" => 77.9, "max_length" => 20],
                    ["value" => $club[6], "x" => 60.6, "y" => 77.9, "max_length" => 8],
                    ["value" => $age[6], "x" => 80, "y" => 77.9, "max_length" => 4],
                    ["value" => $county[6], "x" => 89.5, "y" => 77.9, "max_length" => 5],
                    ["value" => $bib[7], "x" => 18, "y" => 83.2, "max_length" => 4],
                    ["value" => $name[7], "x" => 27.6, "y" => 83.2, "max_length" => 20],
                    ["value" => $club[7], "x" => 60.6, "y" => 83.2, "max_length" => 8],
                    ["value" => $age[7], "x" => 80, "y" => 83.2, "max_length" => 4],
                    ["value" => $county[7], "x" => 89.5, "y" => 83.2, "max_length" => 5],
                    ["value" => $bib[8], "x" => 18, "y" => 89, "max_length" => 4],
                    ["value" => $name[8], "x" => 27.6, "y" => 89, "max_length" => 20],
                    ["value" => $club[8], "x" => 60.6, "y" => 89, "max_length" => 8],
                    ["value" => $age[8], "x" => 80, "y" => 89, "max_length" => 4],
                    ["value" => $county[8], "x" => 89.5, "y" => 89, "max_length" => 5],
                    ["value" => $bib[9], "x" => 18, "y" => 94.7, "max_length" => 4],
                    ["value" => $name[9], "x" => 27.6, "y" => 94.7, "max_length" => 20],
                    ["value" => $club[9], "x" => 60.6, "y" => 94.7, "max_length" => 8],
                    ["value" => $age[9], "x" => 80, "y" => 94.7, "max_length" => 4],
                    ["value" => $county[9], "x" => 89.5, "y" => 94.7, "max_length" => 5],
                    ["value" => $bib[10], "x" => 18, "y" => 100.2, "max_length" => 4],
                    ["value" => $name[10], "x" => 27.6, "y" => 100.2, "max_length" => 20],
                    ["value" => $club[10], "x" => 60.6, "y" => 100.2, "max_length" => 8],
                    ["value" => $age[10], "x" => 80, "y" => 100.2, "max_length" => 4],
                    ["value" => $county[10], "x" => 89.5, "y" => 100.2, "max_length" => 5],
                    ["value" => $bib[11], "x" => 18, "y" => 105.9, "max_length" => 4],
                    ["value" => $name[11], "x" => 27.6, "y" => 105.9, "max_length" => 20],
                    ["value" => $club[11], "x" => 60.6, "y" => 105.9, "max_length" => 8],
                    ["value" => $age[11], "x" => 80, "y" => 105.9, "max_length" => 4],
                    ["value" => $county[11], "x" => 89.5, "y" => 105.9, "max_length" => 5],
                    ["value" => $bib[12], "x" => 18, "y" => 111.5, "max_length" => 4],
                    ["value" => $name[12], "x" => 27.6, "y" => 111.5, "max_length" => 20],
                    ["value" => $club[12], "x" => 60.6, "y" => 111.5, "max_length" => 8],
                    ["value" => $age[12], "x" => 80, "y" => 111.5, "max_length" => 4],
                    ["value" => $county[12], "x" => 89.5, "y" => 111.5, "max_length" => 5],
                    ["value" => $bib[13], "x" => 18, "y" => 117.3, "max_length" => 4],
                    ["value" => $name[13], "x" => 27.6, "y" => 117.3, "max_length" => 20],
                    ["value" => $club[13], "x" => 60.6, "y" => 117.3, "max_length" => 8],
                    ["value" => $age[13], "x" => 80, "y" => 117.3, "max_length" => 4],
                    ["value" => $county[13], "x" => 89.5, "y" => 117.3, "max_length" => 5],
                    ["value" => $bib[14], "x" => 18, "y" => 122.8, "max_length" => 4],
                    ["value" => $name[14], "x" => 27.6, "y" => 122.8, "max_length" => 20],
                    ["value" => $club[14], "x" => 60.6, "y" => 122.8, "max_length" => 8],
                    ["value" => $age[14], "x" => 80, "y" => 122.8, "max_length" => 4],
                    ["value" => $county[14], "x" => 89.5, "y" => 122.8, "max_length" => 5],
                    ["value" => $bib[15], "x" => 18, "y" => 128.3, "max_length" => 4],
                    ["value" => $name[15], "x" => 27.6, "y" => 128.3, "max_length" => 20],
                    ["value" => $club[15], "x" => 60.6, "y" => 128.3, "max_length" => 8],
                    ["value" => $age[15], "x" => 80, "y" => 128.3, "max_length" => 4],
                    ["value" => $county[15], "x" => 89.5, "y" => 128.3, "max_length" => 5],
                    ["value" => $bib[16], "x" => 18, "y" => 134.1, "max_length" => 4],
                    ["value" => $name[16], "x" => 27.6, "y" => 134.1, "max_length" => 20],
                    ["value" => $club[16], "x" => 60.6, "y" => 134.1, "max_length" => 8],
                    ["value" => $age[16], "x" => 80, "y" => 134.1, "max_length" => 4],
                    ["value" => $county[16], "x" => 89.5, "y" => 134.1, "max_length" => 5],
                    ["value" => $bib[17], "x" => 18, "y" => 139.4, "max_length" => 4],
                    ["value" => $name[17], "x" => 27.6, "y" => 139.4, "max_length" => 20],
                    ["value" => $club[17], "x" => 60.6, "y" => 139.4, "max_length" => 8],
                    ["value" => $age[17], "x" => 80, "y" => 139.4, "max_length" => 4],
                    ["value" => $county[17], "x" => 89.5, "y" => 139.4, "max_length" => 5],
                    ["value" => $bib[18], "x" => 18, "y" => 144.8, "max_length" => 4],
                    ["value" => $name[18], "x" => 27.6, "y" => 144.8, "max_length" => 20],
                    ["value" => $club[18], "x" => 60.6, "y" => 144.8, "max_length" => 8],
                    ["value" => $age[18], "x" => 80, "y" => 144.8, "max_length" => 4],
                    ["value" => $county[18], "x" => 89.5, "y" => 144.8, "max_length" => 5],
                    ["value" => $bib[19], "x" => 18, "y" => 150.4, "max_length" => 4],
                    ["value" => $name[19], "x" => 27.6, "y" => 150.4, "max_length" => 20],
                    ["value" => $club[19], "x" => 60.6, "y" => 150.4, "max_length" => 8],
                    ["value" => $age[19], "x" => 80, "y" => 150.4, "max_length" => 4],
                    ["value" => $county[19], "x" => 89.5, "y" => 150.4, "max_length" => 5],
                    ["value" => $eventTime, "x" => 35, "y" => 155.7, "max_length" => 20],
                ];

                // Loop through the data array and write values onto the pdf
                foreach ($data as $item) {
                    $text = $item['value'];
                    $x = $item['x'];
                    $y = $item['y'];
                    $maxLength = $item['max_length'];
                    // Trim text
                    if (strlen($text) > $maxLength) {
                        $text = substr($text, 0, $maxLength) . '..';
                    }
                    // Write values at specific coordinates
                    $pdf->SetXY($x, $y);
                    $pdf->Cell(0, 10, $text, 0, 1);
                }

                // Output PDF to browser in A4 landscape format
                $pdf->Output($outputPath, 'F'); // 'I' for inline display in browser

            }elseif (in_array($eventType, ['PV'])) {
                // Use the specific template for Pole Vault ('PV')
                $templateImage = 'templates/PV.png';
                $pdf = new CustomPDF('L', 'mm', 'A4', true, 'UTF-8', false);

                $pdf->SetCreator(PDF_CREATOR);
                $pdf->SetAuthor('Athletics.app');
                $pdf->SetTitle('Pole Vault Field Card');
                $pdf->SetSubject('Athletics.app');
                $pdf->SetKeywords('Athletics.app');

                $pdf->AddPage('L', 'A4');

                $bMargin = $pdf->getBreakMargin();
                $auto_page_break = $pdf->getAutoPageBreak();
                $pdf->SetAutoPageBreak(false, 0);
                $pdf->Image($templateImage, 0, 0, 297, 210, '', '', '', false, 300, '', false, false, 0);
                $pdf->SetAutoPageBreak($auto_page_break, $bMargin);
                $pdf->setPageMark();

                $pdf->SetFont('helvetica', '', 11);
                $pdf->SetTextColor(0, 0, 0);

                $data = [
                    ["value" => $eventName, "x" => 16.5, "y" => 19, "max_length" =>90],
                    ["value" => $eventDate, "x" => 210, "y" => 19, "max_length" => 15],
                    ["value" => $competitionName, "x" => 7, "y" => 25.9, "max_length" => 70],
                    ["value" => $venueName, "x" => 163, "y" => 25.9, "max_length" => 48],
                    ["value" => $bib[0], "x" => 25, "y" => 43.8, "max_length" => 4],
                    ["value" => $name[0], "x" => 34.5, "y" => 43.8, "max_length" => 17],
                    ["value" => $club[0], "x" => 66.6, "y" => 43.8, "max_length" => 8],
                    ["value" => $age[0], "x" => 86, "y" => 43.8, "max_length" => 4],
                    ["value" => $county[0], "x" => 95.1, "y" => 43.8, "max_length" => 5],
                    ["value" => $bib[1], "x" => 25, "y" => 49.3, "max_length" => 4],
                    ["value" => $name[1], "x" => 34.5, "y" => 49.3, "max_length" => 17],
                    ["value" => $club[1], "x" => 66.6, "y" => 49.3, "max_length" => 8],
                    ["value" => $age[1], "x" => 86, "y" => 49.3, "max_length" => 4],
                    ["value" => $county[1], "x" => 95.1, "y" => 49.3, "max_length" => 5],
                    ["value" => $bib[2], "x" => 25, "y" => 54.9, "max_length" => 4],
                    ["value" => $name[2], "x" => 34.5, "y" => 54.9, "max_length" => 17],
                    ["value" => $club[2], "x" => 66.6, "y" => 54.9, "max_length" => 8],
                    ["value" => $age[2], "x" => 86, "y" => 54.9, "max_length" => 4],
                    ["value" => $county[2], "x" => 95.1, "y" => 54.9, "max_length" => 5],
                    ["value" => $bib[3], "x" => 25, "y" => 60.2, "max_length" => 4],
                    ["value" => $name[3], "x" => 34.5, "y" => 60.2, "max_length" => 17],
                    ["value" => $club[3], "x" => 66.6, "y" => 60.2, "max_length" => 8],
                    ["value" => $age[3], "x" => 86, "y" => 60.2, "max_length" => 4],
                    ["value" => $county[3], "x" => 95.1, "y" => 60.2, "max_length" => 5],
                    ["value" => $bib[4], "x" => 25, "y" => 65.7, "max_length" => 4],
                    ["value" => $name[4], "x" => 34.5, "y" => 65.7, "max_length" => 17],
                    ["value" => $club[4], "x" => 66.6, "y" => 65.7, "max_length" => 8],
                    ["value" => $age[4], "x" => 86, "y" => 65.7, "max_length" => 4],
                    ["value" => $county[4], "x" => 95.1, "y" => 65.7, "max_length" => 5],
                    ["value" => $bib[5], "x" => 25, "y" => 71.2, "max_length" => 4],
                    ["value" => $name[5], "x" => 34.5, "y" => 71.2, "max_length" => 17],
                    ["value" => $club[5], "x" => 66.6, "y" => 71.2, "max_length" => 8],
                    ["value" => $age[5], "x" => 86, "y" => 71.2, "max_length" => 4],
                    ["value" => $county[5], "x" => 95.1, "y" => 71.2, "max_length" => 5],
                    ["value" => $bib[6], "x" => 25, "y" => 76.5, "max_length" => 4],
                    ["value" => $name[6], "x" => 34.5, "y" => 76.5, "max_length" => 17],
                    ["value" => $club[6], "x" => 66.6, "y" => 76.5, "max_length" => 8],
                    ["value" => $age[6], "x" => 86, "y" => 76.5, "max_length" => 4],
                    ["value" => $county[6], "x" => 95.1, "y" => 76.5, "max_length" => 5],
                    ["value" => $bib[7], "x" => 25, "y" => 82, "max_length" => 4],
                    ["value" => $name[7], "x" => 34.5, "y" => 82, "max_length" => 17],
                    ["value" => $club[7], "x" => 66.6, "y" => 82, "max_length" => 8],
                    ["value" => $age[7], "x" => 86, "y" => 82, "max_length" => 4],
                    ["value" => $county[7], "x" => 95.1, "y" => 82, "max_length" => 5],
                    ["value" => $bib[8], "x" => 25, "y" => 87.4, "max_length" => 4],
                    ["value" => $name[8], "x" => 34.5, "y" => 87.4, "max_length" => 17],
                    ["value" => $club[8], "x" => 66.6, "y" => 87.4, "max_length" => 8],
                    ["value" => $age[8], "x" => 86, "y" => 87.4, "max_length" => 4],
                    ["value" => $county[8], "x" => 95.1, "y" => 87.4, "max_length" => 5],
                    ["value" => $bib[9], "x" => 25, "y" => 93, "max_length" => 4],
                    ["value" => $name[9], "x" => 34.5, "y" => 93, "max_length" => 17],
                    ["value" => $club[9], "x" => 66.6, "y" => 93, "max_length" => 8],
                    ["value" => $age[9], "x" => 86, "y" => 93, "max_length" => 4],
                    ["value" => $county[9], "x" => 95.1, "y" => 93, "max_length" => 5],
                    ["value" => $bib[10], "x" => 25, "y" => 98.2, "max_length" => 4],
                    ["value" => $name[10], "x" => 34.5, "y" => 98.2, "max_length" => 17],
                    ["value" => $club[10], "x" => 66.6, "y" => 98.2, "max_length" => 8],
                    ["value" => $age[10], "x" => 86, "y" => 98.2, "max_length" => 4],
                    ["value" => $county[10], "x" => 95.1, "y" => 98.2, "max_length" => 5],
                    ["value" => $bib[11], "x" => 25, "y" => 103.6, "max_length" => 4],
                    ["value" => $name[11], "x" => 34.5, "y" => 103.6, "max_length" => 17],
                    ["value" => $club[11], "x" => 66.6, "y" => 103.6, "max_length" => 8],
                    ["value" => $age[11], "x" => 86, "y" => 103.6, "max_length" => 4],
                    ["value" => $county[11], "x" => 95.1, "y" => 103.6, "max_length" => 5],
                    ["value" => $bib[12], "x" => 25, "y" => 109, "max_length" => 4],
                    ["value" => $name[12], "x" => 34.5, "y" => 109, "max_length" => 17],
                    ["value" => $club[12], "x" => 66.6, "y" => 109, "max_length" => 8],
                    ["value" => $age[12], "x" => 86, "y" => 109, "max_length" => 4],
                    ["value" => $county[12], "x" => 95.1, "y" => 109, "max_length" => 5],
                    ["value" => $bib[13], "x" => 25, "y" => 114.5, "max_length" => 4],
                    ["value" => $name[13], "x" => 34.5, "y" => 114.5, "max_length" => 17],
                    ["value" => $club[13], "x" => 66.6, "y" => 114.5, "max_length" => 8],
                    ["value" => $age[13], "x" => 86, "y" => 114.5, "max_length" => 4],
                    ["value" => $county[13], "x" => 95.1, "y" => 114.5, "max_length" => 5],
                    ["value" => $bib[14], "x" => 25, "y" => 119.8, "max_length" => 4],
                    ["value" => $name[14], "x" => 34.5, "y" => 119.8, "max_length" => 17],
                    ["value" => $club[14], "x" => 66.6, "y" => 119.8, "max_length" => 8],
                    ["value" => $age[14], "x" => 86, "y" => 119.8, "max_length" => 4],
                    ["value" => $county[14], "x" => 95.1, "y" => 119.8, "max_length" => 5],
                    ["value" => $bib[15], "x" => 25, "y" => 125.3, "max_length" => 4],
                    ["value" => $name[15], "x" => 34.5, "y" => 125.3, "max_length" => 17],
                    ["value" => $club[15], "x" => 66.6, "y" => 125.3, "max_length" => 8],
                    ["value" => $age[15], "x" => 86, "y" => 125.3, "max_length" => 4],
                    ["value" => $county[15], "x" => 95.1, "y" => 125.3, "max_length" => 5],
                    ["value" => $bib[16], "x" => 25, "y" => 130.5, "max_length" => 4],
                    ["value" => $name[16], "x" => 34.5, "y" => 130.5, "max_length" => 17],
                    ["value" => $club[16], "x" => 66.6, "y" => 130.5, "max_length" => 8],
                    ["value" => $age[16], "x" => 86, "y" => 130.5, "max_length" => 4],
                    ["value" => $county[16], "x" => 95.1, "y" => 130.5, "max_length" => 5],
                    ["value" => $bib[17], "x" => 25, "y" => 136.2, "max_length" => 4],
                    ["value" => $name[17], "x" => 34.5, "y" => 136.2, "max_length" => 17],
                    ["value" => $club[17], "x" => 66.6, "y" => 136.2, "max_length" => 8],
                    ["value" => $age[17], "x" => 86, "y" => 136.2, "max_length" => 4],
                    ["value" => $county[17], "x" => 95.1, "y" => 136.2, "max_length" => 5],
                    ["value" => $bib[18], "x" => 25, "y" => 141.2, "max_length" => 4],
                    ["value" => $name[18], "x" => 34.5, "y" => 141.2, "max_length" => 17],
                    ["value" => $club[18], "x" => 66.6, "y" => 141.2, "max_length" => 8],
                    ["value" => $age[18], "x" => 86, "y" => 141.2, "max_length" => 4],
                    ["value" => $county[18], "x" => 95.1, "y" => 141.2, "max_length" => 5],
                    ["value" => $bib[19], "x" => 25, "y" => 146.8, "max_length" => 4],
                    ["value" => $name[19], "x" => 34.5, "y" => 146.8, "max_length" => 17],
                    ["value" => $club[19], "x" => 66.6, "y" => 146.8, "max_length" => 8],
                    ["value" => $age[19], "x" => 86, "y" => 146.8, "max_length" => 4],
                    ["value" => $county[19], "x" => 95.1, "y" => 146.8, "max_length" => 5],
                    ["value" => $eventTime, "x" => 35, "y" => 152, "max_length" => 17],
                ];

                // Loop through the data array and write values onto the pdf
                foreach ($data as $item) {
                    $text = $item['value'];
                    $x = $item['x'];
                    $y = $item['y'];
                    $maxLength = $item['max_length'];
                    // Trim text
                    if (strlen($text) > $maxLength) {
                        $text = substr($text, 0, $maxLength) . '..';
                    }
                    // Write values at specific coordinates
                    $pdf->SetXY($x, $y);
                    $pdf->Cell(0, 10, $text, 0, 1);
                }

                // Output PDF to browser in A4 landscape format
                $pdf->Output($outputPath, 'F'); // 'I' for inline display in browser

            }else{
                echo "
                <!DOCTYPE html>
                <html>
                <head> 
                    <meta charset='UTF-8'>
                    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                    <title>Field Cards</title>
                    <style>
                        .page {
                            width: auto;
                            height: auto;
                            display: flex;
                            flex-direction: column;
                            align-items: center;
                            justify-content: center;
                            text-align: center;
                        }
                    </style>
                </head>
                <body>
                        <b>Error - Event Type Not Found</b>
                </body>
                </html>";
            }
        }
}  

/* Example JSON structure of expected input to generate card
$jsonData = '[
    {
        "Competition Name": "Southern Athletics League Meeting One",
        "Event Type": "PV",
        "Event Name": "Pole Vault - Senior Men",
        "Venue Name": "Weir Archer Athletics & Fitness Stadium",
        "Event Time": "13:45",
        "Date": "10/12/2024",
        "Athletes": [
            {"Bib Number": "100", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "101", "Name": "Mike Smith", "Club": "XYZ Club", "Implement": "800g", "Age": "M45", "County": "Surrey"},
            {"Bib Number": "102", "Name": "Charlie Rawlinson", "Club": "Portslade Hoppers", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "103", "Name": "Gordon Lester", "Club": "KACPH", "Implement": "800g", "Age": "U20", "County": "Surrey"},
            {"Bib Number": "104", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "M60", "County": "Surrey"},
            {"Bib Number": "105", "Name": "Mike Smith", "Club": "XYZ Club", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "106", "Name": "Charlie Rawlinson", "Club": "Portslade Hoppers", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "107", "Name": "Gordon Lester", "Club": "KACPH", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "108", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "109", "Name": "Mike Smith", "Club": "XYZ Club", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "110", "Name": "Charlie Rawlinson", "Club": "Portslade Hoppers", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "111", "Name": "Gordon Lester", "Club": "KACPH", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "112", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "113", "Name": "Mike Smith", "Club": "XYZ Club", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "114", "Name": "Charlie Rawlinson", "Club": "Portslade Hoppers", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "115", "Name": "Gordon Lester", "Club": "KACPH", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "116", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "117", "Name": "Mike Smith", "Club": "XYZ Club", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "118", "Name": "Charlie Rawlinson", "Club": "Portslade Hoppers", "Implement": "800g", "Age": "SM", "County": "Surrey"},
            {"Bib Number": "119", "Name": "Gordon Lester", "Club": "KACPH", "Implement": "800g", "Age": "SM", "County": "Surrey"}
        ]
    }
]'; */


?>
