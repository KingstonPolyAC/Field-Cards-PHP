<?php
require_once('TCPDF/tcpdf.php');
require_once('fieldCard.php'); // Include fieldCard.php for generating individual PDFs

function createMergedPDF($jsonInput) {
    // Parse JSON input
    $events = json_decode($jsonInput, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        die("Invalid JSON input");
    }

    $tmpFolder = sys_get_temp_dir() . '/tmp/';
    if (!file_exists($tmpFolder)) {
        mkdir($tmpFolder, 0777, true);
    }

    // Initialize array to hold generated PDF file paths
    $pdfFiles = [];

    // Loop through each event in JSON input and generate a PDF
    foreach ($events as $index => $event) {
        // Generate file path for temporary PDF
        $pdfPath = $tmpFolder . "event_" . $index . ".pdf";
        //var_dump($event);
        // Call modified fieldCard function to generate individual event PDF
        $event = json_encode($event, true);
        //var_dump($event);
        fieldCard($event, $pdfPath);

        // Add generated file to array
        $pdfFiles[] = $pdfPath;
    }

    // Initialize TCPDF for merging
    $pdf = new TCPDF();
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // Loop through each generated PDF and merge into a single PDF
    foreach ($pdfFiles as $file) {
        $pageCount = $pdf->setSourceFile($file);
        for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
            $tplIdx = $pdf->importPage($pageNo);
            $pdf->AddPage();
            $pdf->useTemplate($tplIdx);
        }
    }

    // Output the merged PDF
    $pdf->Output('merged_events.pdf', 'I');

    // Clean up temporary files
    foreach ($pdfFiles as $file) {
        unlink($file);
    }
    rmdir($tmpFolder);
}

/* Sample JSON input
$jsonInput = '[
    {"Competition Name": "Southern Athletics League Meeting One", "Event Type": "PV", "Event Name": "Pole Vault - Senior Men", "Venue Name": "Weir Archer Athletics & Fitness Stadium", "Event Time": "13:45", "Date": "10/12/2024", "Athletes": [{"Bib Number": "100", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "SM", "County": "Surrey"}, {"Bib Number": "101", "Name": "Mike Smith", "Club": "XYZ Club", "Implement": "800g", "Age": "M45", "County": "Surrey"}, {"Bib Number": "102", "Name": "Charlie Rawlinson", "Club": "Portslade Hoppers", "Implement": "800g", "Age": "SM", "County": "Surrey"}, {"Bib Number": "103", "Name": "Gordon Lester", "Club": "KACPH", "Implement": "800g", "Age": "U20", "County": "Surrey"}, {"Bib Number": "104", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "M60", "County": "Surrey"}]},
    {"Competition Name": "Southern Athletics League Meeting One", "Event Type": "HJ", "Event Name": "High Jump - Senior Men", "Venue Name": "Weir Archer Athletics & Fitness Stadium", "Event Time": "13:45", "Date": "10/12/2024", "Athletes": [{"Bib Number": "100", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "SM", "County": "Surrey"}, {"Bib Number": "101", "Name": "Mike Smith", "Club": "XYZ Club", "Implement": "800g", "Age": "M45", "County": "Surrey"}, {"Bib Number": "102", "Name": "Charlie Rawlinson", "Club": "Portslade Hoppers", "Implement": "800g", "Age": "SM", "County": "Surrey"}, {"Bib Number": "103", "Name": "Gordon Lester", "Club": "KACPH", "Implement": "800g", "Age": "U20", "County": "Surrey"}, {"Bib Number": "104", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "M60", "County": "Surrey"}]},
    {"Competition Name": "Southern Athletics League Meeting One", "Event Type": "PV", "Event Name": "Pole Vault - Senior Men", "Venue Name": "Weir Archer Athletics & Fitness Stadium", "Event Time": "13:45", "Date": "10/12/2024", "Athletes": [{"Bib Number": "100", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "SM", "County": "Surrey"}, {"Bib Number": "101", "Name": "Mike Smith", "Club": "XYZ Club", "Implement": "800g", "Age": "M45", "County": "Surrey"}, {"Bib Number": "102", "Name": "Charlie Rawlinson", "Club": "Portslade Hoppers", "Implement": "800g", "Age": "SM", "County": "Surrey"}, {"Bib Number": "103", "Name": "Gordon Lester", "Club": "KACPH", "Implement": "800g", "Age": "U20", "County": "Surrey"}, {"Bib Number": "104", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "M60", "County": "Surrey"}]}
]';*/

$jsonInput = '[
    {"Competition Name": "Southern Athletics League Meeting One", "Event Type": "PV", "Event Name": "Pole Vault - Senior Men", "Venue Name": "Weir Archer Athletics & Fitness Stadium", "Event Time": "13:45", "Date": "10/12/2024", "Athletes": [{"Bib Number": "100", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "SM", "County": "Surrey"}, {"Bib Number": "101", "Name": "Mike Smith", "Club": "XYZ Club", "Implement": "800g", "Age": "M45", "County": "Surrey"}, {"Bib Number": "102", "Name": "Charlie Rawlinson", "Club": "Portslade Hoppers", "Implement": "800g", "Age": "SM", "County": "Surrey"}, {"Bib Number": "103", "Name": "Gordon Lester", "Club": "KACPH", "Implement": "800g", "Age": "U20", "County": "Surrey"}, {"Bib Number": "104", "Name": "John Doe", "Club": "ABC Athletics", "Implement": "800g", "Age": "M60", "County": "Surrey"}]}
]';
createMergedPDF($jsonInput);
?>
